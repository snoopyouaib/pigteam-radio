#include "touchmenu.h"

#ifdef TOUCHMENU_ENABLE
#include "config.h"
#include "controls.h"
#include "player.h"
#include "slideshow.h"
#include "netserver.h"
#include "backlightcontrols.h"
#include "../displays/dspcore.h"

TouchMenu touchmenu;

enum { TL_SLIDE, TL_SCREEN, TL_MODE, TL_ALARM, TL_SLEEP, TL_CLOSE, TL_COUNT };

#define TM_GAP    8
#define TM_BG     0x0000
#define TM_TILE   0x18E3
#define TM_EDGE   0x8410
#define TM_TEXT   0xFFFF
#define TM_OFF    0x7BCF
#define TM_ON     0x07E0
#define TM_WARM   0xFD20

static void tileRect(int i, int W, int H, int& x, int& y, int& w, int& h) {
  w = (W - 4 * TM_GAP) / 3;
  h = (H - 3 * TM_GAP) / 2;
  x = TM_GAP + (i % 3) * (w + TM_GAP);
  y = TM_GAP + (i / 3) * (h + TM_GAP);
}

static bool tileEnabled(int i) {
  switch (i) {
    #ifndef SLIDESHOW_ENABLE
      case TL_SLIDE: return false;
    #endif
    #ifndef ALARM_ENABLE
      case TL_ALARM: return false;
    #endif
    #ifndef SLEEP_TIMER_ENABLE
      case TL_SLEEP: return false;
    #endif
    default: return true;
  }
}

void TouchMenu::open() {
  if (_wantOn || _on) return;
  _armed = false;
  _down = false;
  _pending = -1;
  _closedDone = false;
  _lastAct = millis();
  _wantOn = true;
}

touchMenuEvent_e TouchMenu::poll() {
  if (_wantOn && !_on) { _on = true; _dirty = true; return TME_OPENED; }
  if (_wantOn && _on) return TME_RUNNING;
  if (!_wantOn && _on) { _on = false; return TME_CLOSED; }
  return TME_NONE;
}

void TouchMenu::step() {
  if (!_wantOn) return;
  if (millis() - _lastAct > TOUCHMENU_TIMEOUT_MS) { _wantOn = false; return; }
  if (_dirty) _draw();
}

int TouchMenu::_hit(int x, int y) {
  const int W = dsp.width(), H = dsp.height();
  for (int i = 0; i < TL_COUNT; i++) {
    int tx, ty, tw, th;
    tileRect(i, W, H, tx, ty, tw, th);
    if (x >= tx && x < tx + tw && y >= ty && y < ty + th) return i;
  }
  return -1;   // entre deux boutons : ignore
}

void TouchMenu::touchBegin() {
  if (!_wantOn) return;
  _lastAct = millis();
  if (!_armed) return;
  if (_busy) { _down = false; return; }   // le tactile partage le bus avec l'ecran : on ignore ce qui commence pendant le dessin
  _down = true;
  _t0 = millis();
}

void TouchMenu::touchMove(uint16_t x, uint16_t y) {
  if (!_wantOn) return;
  _x = x;
  _y = y;
  _lastAct = millis();
}

void TouchMenu::touchEnd() {
  if (!_wantOn) return;
  _lastAct = millis();
  if (!_armed) { _armed = true; _down = false; return; }   // relachement du toucher qui a ouvert le menu
  if (!_down) return;
  _down = false;
  if (millis() - _t0 < TOUCHMENU_MIN_PRESS_MS) return;
  switch (_hit(_x, _y)) {
    case TL_SLIDE:  if (tileEnabled(TL_SLIDE)) { _pending = TL_SLIDE;  _wantOn = false; } break;
    case TL_SCREEN: _pending = TL_SCREEN; _wantOn = false; break;
    case TL_MODE:   _pending = TL_MODE;   _wantOn = false; break;
    case TL_CLOSE:  _wantOn = false; break;
    #ifdef ALARM_ENABLE
    case TL_ALARM:
      config.saveValue(&config.store.alarmon, !config.store.alarmon);
      netserver.requestOnChange(ALARM, 0);
      _dirty = true;
      break;
    #endif
    #ifdef SLEEP_TIMER_ENABLE
    case TL_SLEEP: {
      uint16_t m = player.sleepMinutes();
      uint16_t n = (m == 0) ? 15 : (m <= 15) ? 30 : (m <= 30) ? 60 : (m <= 60) ? 90 : 0;
      player.startSleepTimer(n);
      _dirty = true;
      break;
    }
    #endif
    default: break;
  }
}

/* Actions qui touchent a l'affichage ou aux modes : lancees apres la fermeture du menu,
   depuis la tache tactile (comme l'ancien appui long radio <-> SD), jamais depuis la tache d'affichage. */
void TouchMenu::runPending() {
  if (_pending < 0 || !_closedDone) return;
  int a = _pending;
  _pending = -1;
  switch (a) {
    #ifdef SLIDESHOW_ENABLE
    case TL_SLIDE:  slideshow.start(); break;
    #endif
    case TL_SCREEN: config.setDspOn(false); backlightControls.restart(); break;
    case TL_MODE:   controls.onBtnClick(EVT_BTN_MODE); break;
    default: break;
  }
}

void TouchMenu::_drawTile(int i, int W, int H) {
  int x, y, w, h;
  tileRect(i, W, H, x, y, w, h);
  const bool en = tileEnabled(i);
  const char* l1 = "";
  const char* l2 = "";
  char buf[16];
  uint16_t edge = TM_EDGE;
  switch (i) {
    case TL_SLIDE:  l1 = "Diaporama"; l2 = "photos SD"; break;
    case TL_SCREEN: l1 = "Ecran";     l2 = "eteindre"; break;
    case TL_MODE:   l1 = (config.getMode() == PM_WEB) ? "Mode SD" : "Mode Radio"; l2 = "basculer"; break;
    case TL_ALARM:
      l1 = "Reveil";
      #ifdef ALARM_ENABLE
        l2 = config.store.alarmon ? "ON" : "OFF";
        if (config.store.alarmon) edge = TM_ON;
      #endif
      break;
    case TL_SLEEP:
      l1 = "Arret prog.";
      l2 = "non";
      #ifdef SLEEP_TIMER_ENABLE
        if (player.sleepMinutes()) { snprintf(buf, sizeof(buf), "%u min", (unsigned)player.sleepMinutes()); l2 = buf; edge = TM_WARM; }
      #endif
      break;
    default: l1 = "Fermer"; break;
  }
  dsp.fillRoundRect(x, y, w, h, 10, TM_TILE);
  dsp.drawRoundRect(x, y, w, h, 10, en ? edge : TM_OFF);
  dsp.setFont();
  dsp.setTextWrap(false);
  dsp.setTextColor(en ? TM_TEXT : TM_OFF);
  dsp.setTextSize(2);
  int tw1 = (int)strlen(l1) * 12;
  dsp.setCursor(x + (w - tw1) / 2, y + h / 2 - (l2[0] ? 20 : 8));
  dsp.print(l1);
  if (l2[0]) {
    int tw2 = (int)strlen(l2) * 12;
    dsp.setCursor(x + (w - tw2) / 2, y + h / 2 + 6);
    dsp.print(en ? l2 : "---");
  }
}

void TouchMenu::_draw() {
  _busy = true;
  _dirty = false;
  const int W = dsp.width(), H = dsp.height();
  dsp.fillScreen(TM_BG);
  for (int i = 0; i < TL_COUNT; i++) _drawTile(i, W, H);
  _busy = false;
}
#endif // TOUCHMENU_ENABLE
